USE proyecto2;

INSERT INTO usuarios VALUES ('jairo','1234','jgarcia',0,0,0,0);
INSERT INTO usuarios VALUES ('abel','1234','abel123',0,0,0,0);

INSERT INTO equipos VALUES ('mexico','a','grupo','verde',0,0,0,0,0);
INSERT INTO equipos VALUES ('guatemala','a','grupo','verde',0,0,0,0,0);
INSERT INTO equipos VALUES ('honduras','a','grupo','verde',0,0,0,0,0);
INSERT INTO equipos VALUES ('belice','a','grupo','verde',0,0,0,0,0);

INSERT INTO equipos VALUES ('ecuador','b','final','azul',0,0,0,0,0);
INSERT INTO equipos VALUES ('argentina','b','final','azul',0,0,0,0,0);
INSERT INTO equipos VALUES ('venezuela','b','grupo','azul',0,0,0,0,0);
INSERT INTO equipos VALUES ('nigeria','b','grupo','azul',0,0,0,0,0);


INSERT INTO equipos VALUES ('portugal','c','cuartos','amarillo',0,0,0,0,0);
INSERT INTO equipos VALUES ('francia','c','cuartos','amarillo',0,0,0,0,0);
INSERT INTO equipos VALUES ('india','c','octavos','amarillo',0,0,0,0,0);
INSERT INTO equipos VALUES ('canada','c','octavos','amarillo',0,0,0,0,0);


INSERT INTO equipos VALUES ('nicaragua','d','cuartos','rojo',0,0,0,0,0);
INSERT INTO equipos VALUES ('siria','d','cuartos','rojo',0,0,0,0,0);
INSERT INTO equipos VALUES ('israel','d','semifinal','rojo',0,0,0,0,0);
INSERT INTO equipos VALUES ('italia','d','semifinal','rojo',0,0,0,0,0);

INSERT INTO equipo1 VALUES (0,'mexico',1);
INSERT INTO equipo2 VALUES (0,'guatemala',1);

INSERT INTO equipo1 VALUES (0,'honduras',2);
INSERT INTO equipo2 VALUES (0,'belice',2);

INSERT INTO equipo1 VALUES (0,'venezuela',3);
INSERT INTO equipo2 VALUES (0,'nigeria',3);

INSERT INTO equipo1 VALUES (0,'ecuador',4);
INSERT INTO equipo2 VALUES (0,'argentina',4);

INSERT INTO equipo1 VALUES (0,'portugal',5);
INSERT INTO equipo2 VALUES (0,'francia',5);


INSERT INTO equipo1 VALUES (0,'india',6);
INSERT INTO equipo2 VALUES (0,'canada',6);


INSERT INTO equipo1 VALUES (0,'nicaragua',7);
INSERT INTO equipo2 VALUES (0,'siria',7);


INSERT INTO equipo1 VALUES (0,'israel',8);
INSERT INTO equipo2 VALUES (0,'italia',8);

INSERT INTO partidos VALUES ("2022-01-10","1:10",1);
INSERT INTO partidos VALUES ("2022-01-11","1:10",2);
INSERT INTO partidos VALUES ("2022-01-12","1:10",3);
INSERT INTO partidos VALUES ("2022-01-13","1:10",4);
INSERT INTO partidos VALUES ("2022-01-14","1:10",5);
INSERT INTO partidos VALUES ("2022-01-15","1:10",6);
INSERT INTO partidos VALUES ("2022-01-16","1:10",7);
INSERT INTO partidos VALUES ("2022-01-17","1:10",8);
